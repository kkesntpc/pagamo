let isBotRunning = false;
let startX = 0;
let startY = 4000;
let totalLoops = 400; // 迴圈次數

ensureBotUI();

function ensureBotUI() {
  if (document.getElementById('pagamo-coord-bot-widget')) return;

  const widget = document.createElement('div');
  widget.id = 'pagamo-coord-bot-widget';
  widget.style.cssText = `
    position: fixed !important;
    top: 80px !important;
    right: 20px !important;
    z-index: 2147483647 !important;
    background: #ffffff !important;
    border: 2px solid #28a745 !important;
    border-radius: 8px !important;
    padding: 10px !important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3) !important;
    font-family: sans-serif !important;
    width: 220px !important;
    font-size: 13px !important;
  `;

  widget.innerHTML = `
    <div style="font-weight: bold; text-align: center; margin-bottom: 6px; color: #28a745; font-size: 14px;">
      🎯 PaGamO 迴圈自動攻地與補血
    </div>
    <div style="margin-bottom: 6px;">
      <label>起始 X：<input type="number" id="bot-x-input" value="${startX}" style="width: 50px;"></label>
      <label> Y：<input type="number" id="bot-y-input" value="${startY}" style="width: 60px;"></label>
    </div>
    <div style="margin-bottom: 6px;">
      <label>迴圈數：<input type="number" id="bot-loop-input" value="${totalLoops}" style="width: 60px;"></label>
    </div>
    <div style="margin-bottom: 8px; font-size: 12px; color: #555;">
      狀態：<b id="bot-status-text" style="color: #dc3545;">待命</b>
    </div>
    <button id="bot-start-btn" style="width:100%; padding:6px; background:#28a745; color:white; border:none; border-radius:4px; font-weight:bold; cursor:pointer;">開始連續執行</button>
    <button id="bot-stop-btn" style="width:100%; padding:6px; background:#dc3545; color:white; border:none; border-radius:4px; font-weight:bold; cursor:pointer; display:none;">停止</button>
  `;

  (document.body || document.documentElement).appendChild(widget);

  document.getElementById('bot-start-btn').addEventListener('click', startLoopProcess);
  document.getElementById('bot-stop-btn').addEventListener('click', stopBot);
}

// 主流程：對應按鍵精靈 For j = 0 To 400
async function startLoopProcess() {
  isBotRunning = true;
  updateUIState(true);

  startX = parseInt(document.getElementById('bot-x-input').value, 10);
  startY = parseInt(document.getElementById('bot-y-input').value, 10);
  totalLoops = parseInt(document.getElementById('bot-loop-input').value, 10) || 400;

  for (let j = 0; j < totalLoops; j++) {
    if (!isBotRunning) break;

    const currentX = startX;
    const currentY = startY - j; // Y 逐次遞減 (往上/移動)

    logStatus(`[${j + 1}/${totalLoops}] 處理座標: (${currentX}, ${currentY})`);

    // 1. 檢查並執行補血功能 (檢查藥水或血條)
    await checkAndHeal();

    if (!isBotRunning) break;

    // 2. 如果目前已經開著答題視窗，直接答題
    if (isQuizWindowPresent()) {
      logStatus("⚡ 偵測到已有答題視窗，直接答題...");
      await handleAutoAnswer();
      await sleep(1000);
      continue;
    }

    // 3. 輸入座標並前往
    logStatus(`1. 輸入座標 (${currentX}, ${currentY})...`);
    await navigateToCoord(currentX, currentY);

    if (!isBotRunning) break;
    await sleep(1800); // 等待地圖平移動畫

    // 4. 點擊地圖中央（相當於按鍵精靈中的 MoveTo 714, 470）
    logStatus("2. 點擊地圖中央格...");
    clickTargetTileCenter();

    if (!isBotRunning) break;
    await sleep(1500);

    // 5. 點擊前進/訓練按鈕（相當於 MoveR 0, -130）
    logStatus("3. 點擊盾牌前進按鈕...");
    const actionClicked = clickShieldActionBtn();

    if (!actionClicked) {
      logStatus("⚠️ 未偵測到前進按鈕，跳過此格");
      await sleep(1000);
      continue;
    }

    if (!isBotRunning) break;
    await sleep(1800);

    // 6. 等待題目頁面完全載入
    logStatus("4. 等待題目頁面載入...");
    const hasQuestion = await waitForQuestionWindow(6000);

    if (!hasQuestion) {
      logStatus("⚠️ 未偵測到答題頁面，繼續下一格");
      await sleep(1000);
      continue;
    }

    // 7. 選答案並送出 (對應按鍵精靈選答案與送出流程)
    await handleAutoAnswer();

    if (!isBotRunning) break;
    await sleep(1500);

    // 8. 嘗試關閉視窗 (對應按鍵精靈點擊關閉按鈕)
    await closeQuizWindow();
    await sleep(1000);
  }

  logStatus("連線任務執行完成或已停止");
  stopBot();
}

// 補血檢查機制 (對應 FindColorEx 判斷與吃藥流程)
async function checkAndHeal() {
  // 尋找補血/吃藥水圖示或體力補充按鈕
  const healBtn = Array.from(document.querySelectorAll('button, div, img, span, a')).find(el => {
    const txt = (el.innerText || '') + (el.getAttribute('alt') || '') + (el.getAttribute('title') || '');
    return /(藥水|補充|吃藥|回復體力|Heal|Potion)/i.test(txt) && el.offsetWidth > 0;
  });

  if (healBtn) {
    logStatus("❤️ 偵測到體力低下/藥水按鈕，執行補血...");
    fullRealClick(healBtn);
    await sleep(1000);

    // 點擊確認/使用按鈕
    const confirmBtn = Array.from(document.querySelectorAll('button, div, span')).find(el => {
      const txt = (el.innerText || '').trim();
      return /^(使用|確認|OK|確定)$/.test(txt) && el.offsetWidth > 0;
    });

    if (confirmBtn) {
      fullRealClick(confirmBtn);
      await sleep(1000);
    }
  }
}

// 關閉視窗 (對應按鍵精靈關閉視窗步驟)
async function closeQuizWindow() {
  const closeBtn = document.querySelector('.close-btn, .btn-close, [class*="close"], [aria-label="Close"]');
  if (closeBtn && closeBtn.offsetWidth > 0) {
    fullRealClick(closeBtn);
  }
}

function stopBot() {
  isBotRunning = false;
  updateUIState(false);
  logStatus("已停止");
}

function isQuizWindowPresent() {
  const options = getOptionElements();
  return options.length > 0;
}

// 1. 輸入座標與 Enter 跳轉
async function navigateToCoord(x, y) {
  const inputs = Array.from(document.querySelectorAll('input')).filter(i => {
    const rect = i.getBoundingClientRect();
    return rect.left < 300 && rect.top > 0 && i.offsetWidth > 0;
  });

  if (inputs.length >= 2) {
    setInputValue(inputs[0], x);
    setInputValue(inputs[1], y);

    await sleep(400);

    inputs[1].focus();
    const enterEvtInit = { key: 'Enter', keyCode: 13, code: 'Enter', which: 13, bubbles: true, cancelable: true };
    inputs[1].dispatchEvent(new KeyboardEvent('keydown', enterEvtInit));
    inputs[1].dispatchEvent(new KeyboardEvent('keyup', enterEvtInit));

    const searchBtn = document.querySelector('button[class*="search"], div[class*="search"], .search-icon, [class*="magnifier"]');
    if (searchBtn) fullRealClick(searchBtn);
  }
}

function setInputValue(inputEl, value) {
  inputEl.value = value;
  inputEl.dispatchEvent(new Event('input', { bubbles: true }));
  inputEl.dispatchEvent(new Event('change', { bubbles: true }));
}

// 2. 點擊地圖目標準心
function clickTargetTileCenter() {
  const widget = document.getElementById('pagamo-coord-bot-widget');
  if (widget) widget.style.pointerEvents = 'none';

  const targetEl = document.elementFromPoint(683, 430);
  if (targetEl) {
    fullRealClick(targetEl, 683, 430);
  }

  if (widget) widget.style.pointerEvents = 'auto';
}

// 3. 點擊盾牌「訓練/前進」按鈕
function clickShieldActionBtn() {
  const widget = document.getElementById('pagamo-coord-bot-widget');
  if (widget) widget.style.pointerEvents = 'none';

  const allElements = Array.from(document.querySelectorAll('button, div, img, span, a'));
  const actionBtn = allElements.find(el => {
    const txt = ((el.innerText || '') + (el.getAttribute('alt') || '') + (el.getAttribute('title') || '')).trim();
    return /^(訓練|前進|進攻|攻擊)$/.test(txt) && el.offsetWidth > 0 && el.offsetHeight > 0;
  });

  let success = false;
  if (actionBtn) {
    fullRealClick(actionBtn);
    success = true;
  } else {
    const targetEl = document.elementFromPoint(683, 320);
    if (targetEl) {
      fullRealClick(targetEl, 683, 320);
      success = true;
    }
  }

  if (widget) widget.style.pointerEvents = 'auto';
  return success;
}

// 4. 等待題目頁面載入
async function waitForQuestionWindow(timeoutMs) {
  const startTime = Date.now();

  while (Date.now() - startTime < timeoutMs) {
    if (!isBotRunning) return false;
    if (isQuizWindowPresent()) return true;
    await sleep(300);
  }
  return false;
}

// 抓取選項 (A, B, C, D 或 O, X)
function getOptionElements() {
  return Array.from(document.querySelectorAll('div, li, button')).filter(el => {
    const txt = (el.innerText || '').trim();
    const isQuestion = el.classList.contains('quiz-content') || el.classList.contains('question-text');
    const isOptionFormat = /^[A-D][\.\s、]/i.test(txt) || /^(O|X|True|False)$/i.test(txt);
    return !isQuestion && isOptionFormat && el.offsetWidth > 30 && el.offsetHeight > 20;
  });
}

// 5. 選擇答案並送出
async function handleAutoAnswer() {
  const questionBank = window.pagamoQuestionBank || {};

  const questionEl = document.querySelector('.quiz-content, .question-text, [class*="question"]');
  const questionText = questionEl ? questionEl.innerText.trim() : '';

  const options = getOptionElements();
  if (options.length === 0) {
    logStatus("⚠️ 未偵測到選項");
    return;
  }

  let chosenIndex = -1;

  for (const [key, ansIdx] of Object.entries(questionBank)) {
    if (questionText && (questionText.includes(key) || key.includes(questionText))) {
      chosenIndex = ansIdx;
      break;
    }
  }

  if (chosenIndex === -1 || chosenIndex >= options.length) {
    chosenIndex = Math.floor(Math.random() * options.length);
    logStatus(`⚠️ 盲猜選第 ${chosenIndex + 1} 個選項...`);
  } else {
    logStatus(`🎯 題庫命中，選第 ${chosenIndex + 1} 個選項...`);
  }

  const targetOptionEl = options[chosenIndex];

  fullRealClick(targetOptionEl);
  await sleep(300);
  fullRealClick(targetOptionEl);

  await sleep(1500);

  const submitBtn = Array.from(document.querySelectorAll('button, div, span, a')).find(btn => {
    const txt = (btn.innerText || '').trim();
    return /^(送出|確認|提交)$/.test(txt) && btn.offsetWidth > 0;
  });

  if (submitBtn) {
    logStatus("✅ 選項已選中，點擊送出！");
    fullRealClick(submitBtn);
  } else {
    logStatus("⚠️ 未找到送出按鈕");
  }
}

// DOM 原生點擊觸發器
function fullRealClick(el, clientX = null, clientY = null) {
  if (!el) return;

  const rect = el.getBoundingClientRect();
  const x = clientX !== null ? clientX : rect.left + rect.width / 2;
  const y = clientY !== null ? clientY : rect.top + rect.height / 2;

  const evtInit = {
    clientX: x,
    clientY: y,
    screenX: x,
    screenY: y,
    bubbles: true,
    cancelable: true,
    view: window,
    buttons: 1
  };

  try {
    el.focus();
    el.click();
  } catch(e) {}

  ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(evtName => {
    try {
      if (evtName.startsWith('pointer')) {
        el.dispatchEvent(new PointerEvent(evtName, evtInit));
      } else {
        el.dispatchEvent(new MouseEvent(evtName, evtInit));
      }
    } catch (e) {}
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function logStatus(text) {
  const statusEl = document.getElementById('bot-status-text');
  if (statusEl) statusEl.textContent = text;
}

function updateUIState(running) {
  document.getElementById('bot-start-btn').style.display = running ? 'none' : 'block';
  document.getElementById('bot-stop-btn').style.display = running ? 'block' : 'none';
}