'use strict';

/*
 * ============================================================
 * PaGamO 座標助手
 * background.js
 * ============================================================
 *
 * Background Service Worker 負責：
 *
 * 1. 接收 Content Script 訊息
 * 2. 查詢目前分頁
 * 3. 截圖
 * 4. 下載圖片
 * 5. 控制流程狀態
 *
 * ============================================================
 */

let isRunning = false;

let currentIndex = 0;

let totalQuestions = 0;

let delayMs = 1500;

let fileSuffix = '';

let processToken = 0;


/* ============================================================
 * 工具
 * ============================================================ */

function sleep(ms) {
  return new Promise(resolve => {
    setTimeout(resolve, ms);
  });
}


/* ============================================================
 * 啟動
 * ============================================================ */

console.log(
  '[PaGamO] background.js 啟動'
);


/* ============================================================
 * 接收訊息
 * ============================================================ */

chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {

    if (!request || !request.action) {
      return;
    }

    console.log(
      '[PaGamO Background]',
      request
    );


    /* --------------------------------------------------------
     * 開始題目流程
     * -------------------------------------------------------- */

    if (request.action === 'startProcess') {

      if (isRunning) {

        sendResponse({
          success: false,
          message: '目前已經在執行'
        });

        return true;
      }


      isRunning = true;

      currentIndex = 0;


      delayMs =
        Number(request.delay) > 0
          ? Number(request.delay)
          : 1500;


      fileSuffix =
        request.suffix
          ? '_' + sanitizeFilename(request.suffix)
          : '';


      totalQuestions =
        Number(request.totalCount) > 0
          ? Number(request.totalCount)
          : 0;


      processToken++;

      const token = processToken;


      startProcessLoop(token)
        .catch(error => {

          console.error(
            '[PaGamO] 流程錯誤:',
            error
          );


          isRunning = false;

          notifyUI();
        });


      sendResponse({
        success: true
      });


      return true;
    }


    /* --------------------------------------------------------
     * 停止
     * -------------------------------------------------------- */

    if (request.action === 'stopProcess') {

      isRunning = false;

      processToken++;


      notifyUI();


      sendResponse({
        success: true
      });


      return true;
    }


    /* --------------------------------------------------------
     * 取得狀態
     * -------------------------------------------------------- */

    if (request.action === 'getProcessStatus') {

      sendResponse({
        success: true,
        isRunning,
        current: currentIndex,
        total: totalQuestions
      });


      return true;
    }


    /* --------------------------------------------------------
     * 手動截圖
     * -------------------------------------------------------- */

    if (request.action === 'captureCurrentTab') {

      captureCurrentTab(
        request.filename || 'Question.png'
      )
        .then(result => {

          sendResponse(result);

        })
        .catch(error => {

          sendResponse({
            success: false,
            error: error.message
          });

        });


      return true;
    }

  }
);


/* ============================================================
 * 取得目前分頁
 * ============================================================ */

async function getActiveTab() {

  const tabs =
    await chrome.tabs.query({
      active: true,
      currentWindow: true
    });


  if (!tabs || tabs.length === 0) {
    return null;
  }


  return tabs[0];
}


/* ============================================================
 * 題目流程
 * ============================================================ */

async function startProcessLoop(token) {

  const tab =
    await getActiveTab();


  if (!tab || !tab.id) {

    isRunning = false;

    await notifyUI();

    return;
  }


  /* --------------------------------------------------------
   * 自動取得題數
   * -------------------------------------------------------- */

  if (!totalQuestions) {

    try {

      const results =
        await chrome.scripting.executeScript({

          target: {
            tabId: tab.id,
            allFrames: true
          },

          func: scanTotalQuestions

        });


      for (const item of results) {

        if (
          item &&
          typeof item.result === 'number' &&
          item.result > 0
        ) {

          totalQuestions =
            item.result;

          break;
        }
      }

    } catch (error) {

      console.warn(
        '[PaGamO] 無法自動取得題數',
        error
      );
    }


    /*
     * 找不到時使用保守預設值
     */

    if (!totalQuestions) {
      totalQuestions = 19;
    }
  }


  await notifyUI();


  /* --------------------------------------------------------
   * 題目迴圈
   * -------------------------------------------------------- */

  while (
    isRunning &&
    token === processToken &&
    currentIndex < totalQuestions
  ) {

    const index =
      currentIndex;


    console.log(
      `[PaGamO] 題目 ${index + 1}/${totalQuestions}`
    );


    await notifyUI();


    /* ------------------------------------------------------
     * 要求 Content Script 切換題目
     * ------------------------------------------------------ */

    try {

      await chrome.tabs.sendMessage(
        tab.id,
        {
          action: 'clickQuestion',
          index
        }
      );

    } catch (error) {

      console.warn(
        '[PaGamO] 題目切換失敗',
        error
      );
    }


    /* ------------------------------------------------------
     * 等待頁面更新
     * ------------------------------------------------------ */

    await sleep(delayMs);


    if (
      !isRunning ||
      token !== processToken
    ) {
      break;
    }


    /* ------------------------------------------------------
     * 截圖
     * ------------------------------------------------------ */

    try {

      const number =
        String(index + 1)
          .padStart(4, '0');


      const filename =
        `Question_${number}${fileSuffix}.png`;


      await captureCurrentTab(
        filename,
        tab.windowId
      );

    } catch (error) {

      console.error(
        '[PaGamO] 截圖失敗',
        error
      );
    }


    currentIndex++;


    await sleep(200);
  }


  /* --------------------------------------------------------
   * 結束
   * -------------------------------------------------------- */

  if (token === processToken) {

    isRunning = false;

    await notifyUI();
  }


  console.log(
    '[PaGamO] 題目流程完成'
  );
}


/* ============================================================
 * 通知 UI
 * ============================================================ */

async function notifyUI() {

  try {

    const tab =
      await getActiveTab();


    if (!tab || !tab.id) {
      return;
    }


    await chrome.tabs.sendMessage(
      tab.id,
      {
        action: 'updateUI',

        isRunning,

        current:
          currentIndex + 1,

        total:
          totalQuestions
      }
    );

  } catch (error) {

    /*
     * 頁面沒有 Content Script 時忽略
     */

  }
}


/* ============================================================
 * 截圖
 * ============================================================ */

async function captureCurrentTab(
  filename,
  windowId = null
) {

  let targetWindow =
    windowId;


  if (!targetWindow) {

    const tab =
      await getActiveTab();


    if (!tab) {

      throw new Error(
        '找不到目前分頁'
      );
    }


    targetWindow =
      tab.windowId;
  }


  const dataUrl =
    await chrome.tabs.captureVisibleTab(
      targetWindow,
      {
        format: 'png'
      }
    );


  const safeFilename =
    sanitizeFilename(
      filename
    );


  const downloadId =
    await chrome.downloads.download({

      url: dataUrl,

      filename: safeFilename,

      saveAs: false,

      conflictAction: 'uniquify'

    });


  console.log(
    '[PaGamO] 已下載:',
    safeFilename
  );


  return {

    success: true,

    downloadId,

    filename: safeFilename

  };
}


/* ============================================================
 * 檔名清理
 * ============================================================ */

function sanitizeFilename(filename) {

  return String(filename)

    .replace(
      /[<>:"/\\|?*\x00-\x1F]/g,
      '_'
    )

    .replace(
      /\s+/g,
      ' '
    )

    .trim()

    .slice(
      0,
      180
    );
}


/* ============================================================
 * 頁面題數掃描
 * ============================================================ */

function scanTotalQuestions() {

  const text =
    document.body
      ? document.body.innerText || ''
      : '';


  let match;


  /*
   * 已篩選 (19)
   */

  match =
    text.match(
      /已篩選\s*\(\s*(\d+)\s*\)/
    );


  if (match) {

    return parseInt(
      match[1],
      10
    );
  }


  /*
   * 已選取題目：19 題
   */

  match =
    text.match(
      /已選取題目\s*[:：]\s*(\d+)\s*題/
    );


  if (match) {

    return parseInt(
      match[1],
      10
    );
  }


  /*
   * 題目 1 / 19
   */

  match =
    text.match(
      /(?:題目|Question)\s*\d+\s*[/／]\s*(\d+)/
    );


  if (match) {

    return parseInt(
      match[1],
      10
    );
  }


  return 0;
}