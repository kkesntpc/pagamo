'use strict';

/*
 * ============================================================
 * PaGamO 座標助手
 * content.js (React 表單破解版)
 * ============================================================
 *
 * 負責：
 * 1. 網頁控制面板 (浮動 UI)
 * 2. 座標輸入與原生 DOM 強效事件觸發
 * 3. 破解 React Form requestSubmit 自動跳轉
 * 4. 題目切換 DOM 點擊
 * ============================================================
 */

let isBotRunning = false;
let startX = 5280;
let startY = -10822;
let totalLoops = 2;

/* ============================================================
 * 啟動
 * ============================================================ */

init();

function init() {
  ensureBotUI();

  /*
   * 網站如果重新 render，
   * UI 被移除後自動重新建立。
   */
  setInterval(ensureBotUI, 1000);

  console.log('[PaGamO] content.js (強效跳轉版) 啟動');
}

/* ============================================================
 * UI 控制面板
 * ============================================================ */

function ensureBotUI() {
  if (document.getElementById('pagamo-coord-bot-widget')) {
    return;
  }

  if (!document.documentElement) {
    return;
  }

  const widget = document.createElement('div');
  widget.id = 'pagamo-coord-bot-widget';

  widget.style.cssText = `
    position: fixed !important;
    top: 80px !important;
    left: 20px !important;
    width: 230px !important;
    z-index: 2147483647 !important;
    background: #ffffff !important;
    color: #111111 !important;
    border: 3px solid #198754 !important;
    border-radius: 10px !important;
    padding: 11px !important;
    box-sizing: border-box !important;
    box-shadow: 0 6px 20px rgba(0,0,0,0.35) !important;
    font-family: Arial, "Microsoft JhengHei", sans-serif !important;
    font-size: 13px !important;
    user-select: none !important;
  `;

  widget.innerHTML = `
    <div
      id="bot-widget-header"
      style="
        font-weight:bold;
        text-align:center;
        color:#146c43;
        font-size:15px;
        padding-bottom:7px;
        margin-bottom:9px;
        border-bottom:1px solid #cccccc;
        cursor:move;
      "
    >
      🚀 PaGamO 座標助手
    </div>

    <div
      style="
        display:flex;
        align-items:center;
        justify-content:space-between;
        margin-bottom:7px;
      "
    >
      <label for="bot-x-input" style="font-weight:bold;">起始 X</label>
      <input
        id="bot-x-input"
        type="number"
        value="${startX}"
        style="
          width:120px;
          padding:5px;
          box-sizing:border-box;
          border:1px solid #777;
          border-radius:4px;
          color:#111;
          background:#fff;
        "
      >
    </div>

    <div
      style="
        display:flex;
        align-items:center;
        justify-content:space-between;
        margin-bottom:7px;
      "
    >
      <label for="bot-y-input" style="font-weight:bold;">起始 Y</label>
      <input
        id="bot-y-input"
        type="number"
        value="${startY}"
        style="
          width:120px;
          padding:5px;
          box-sizing:border-box;
          border:1px solid #777;
          border-radius:4px;
          color:#111;
          background:#fff;
        "
      >
    </div>

    <div
      style="
        display:flex;
        align-items:center;
        justify-content:space-between;
        margin-bottom:9px;
      "
    >
      <label for="bot-loop-input" style="font-weight:bold;">迴圈數</label>
      <input
        id="bot-loop-input"
        type="number"
        min="1"
        value="${totalLoops}"
        style="
          width:120px;
          padding:5px;
          box-sizing:border-box;
          border:1px solid #777;
          border-radius:4px;
          color:#111;
          background:#fff;
        "
      >
    </div>

    <div
      style="
        background:#f1f3f5;
        border:1px solid #cccccc;
        border-radius:5px;
        padding:7px;
        margin-bottom:9px;
        text-align:center;
        color:#222;
        line-height:1.5;
      "
    >
      狀態：<b id="bot-status-text" style="color:#b02a37;">待命</b>
    </div>

    <button
      id="bot-start-btn"
      type="button"
      style="
        display:block;
        width:100%;
        padding:8px;
        margin-bottom:6px;
        border:0;
        border-radius:5px;
        background:#198754;
        color:#fff;
        font-weight:bold;
        cursor:pointer;
      "
    >
      開始連續飛地圖
    </button>

    <button
      id="bot-stop-btn"
      type="button"
      style="
        display:none;
        width:100%;
        padding:8px;
        border:0;
        border-radius:5px;
        background:#dc3545;
        color:#fff;
        font-weight:bold;
        cursor:pointer;
      "
    >
      停止
    </button>
  `;

  document.documentElement.appendChild(widget);
  setupWidgetEvents(widget);
  makeWidgetDraggable(widget);
}

/* ============================================================
 * UI 事件與拖曳
 * ============================================================ */

function setupWidgetEvents(widget) {
  const startButton = widget.querySelector('#bot-start-btn');
  const stopButton = widget.querySelector('#bot-stop-btn');

  if (startButton) {
    startButton.addEventListener('click', startLoopProcess);
  }

  if (stopButton) {
    stopButton.addEventListener('click', stopBot);
  }
}

function makeWidgetDraggable(element) {
  const header = element.querySelector('#bot-widget-header');
  if (!header) return;

  let dragging = false;
  let startMouseX = 0, startMouseY = 0;
  let startLeft = 0, startTop = 0;

  header.addEventListener('mousedown', event => {
    if (event.target.closest('input,button')) return;

    dragging = true;
    startMouseX = event.clientX;
    startMouseY = event.clientY;

    const rect = element.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;

    event.preventDefault();
  });

  document.addEventListener('mousemove', event => {
    if (!dragging) return;
    const newLeft = startLeft + event.clientX - startMouseX;
    const newTop = startTop + event.clientY - startMouseY;

    element.style.left = `${Math.max(0, newLeft)}px`;
    element.style.top = `${Math.max(0, newTop)}px`;
  });

  document.addEventListener('mouseup', () => {
    dragging = false;
  });
}

/* ============================================================
 * 開始飛地圖迴圈
 * ============================================================ */

async function startLoopProcess() {
  if (isBotRunning) return;

  const xInput = document.getElementById('bot-x-input');
  const yInput = document.getElementById('bot-y-input');
  const loopInput = document.getElementById('bot-loop-input');

  if (!xInput || !yInput || !loopInput) {
    setStatus('找不到設定欄位');
    return;
  }

  startX = Number(xInput.value);
  startY = Number(yInput.value);
  totalLoops = Number(loopInput.value);

  if (!Number.isFinite(startX) || !Number.isFinite(startY)) {
    setStatus('座標輸入錯誤');
    return;
  }

  if (!Number.isInteger(totalLoops) || totalLoops < 1) {
    setStatus('迴圈數錯誤');
    return;
  }

  isBotRunning = true;
  updateButtons(true);

  try {
    for (let i = 0; i < totalLoops; i++) {
      if (!isBotRunning) break;

      const x = startX;
      const y = startY - i;

      setStatus(`[${i + 1}/${totalLoops}] (${x}, ${y})`);

      const success = await flyToCoord(x, y);

      if (!success) {
        setStatus(`[${i + 1}/${totalLoops}] 跳轉觸發失敗`);
        break;
      }

      // 等待 3.5 秒讓地圖飛行停穩
      await sleep(3500);
    }

    if (isBotRunning) {
      setStatus('任務完成');
    }
  } catch (error) {
    console.error('[PaGamO]', error);
    setStatus('執行錯誤');
  } finally {
    isBotRunning = false;
    updateButtons(false);
  }
}

/* ============================================================
 * 🎯 座標跳轉操作 (解決 React Form requestSubmit 問題)
 * ============================================================ */

async function flyToCoord(x, y) {
  const inputs = findCoordinateInputs();

  if (inputs.length < 2) {
    console.warn('[PaGamO] 找不到座標輸入框');
    return false;
  }

  const xInput = inputs[0];
  const yInput = inputs[1];

  console.log('[PaGamO] 填寫座標:', x, y);

  // 1. 強效寫入 X 欄位
  setNativeValue(xInput, x);
  await sleep(200);

  // 2. 強效寫入 Y 欄位
  setNativeValue(yInput, y);
  await sleep(300);

  // 3. 尋找座標跳轉按鈕 (<button type="submit">)
  const button = findCoordinateButton(yInput);

  if (button) {
    console.log('[PaGamO] 觸發跳轉按鈕:', button);

    const form = yInput.form || button.closest('form');

    // (A) 對按鈕發送完整連環 Mouse / Pointer 事件鏈，觸發 onClick
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(evtName => {
      button.dispatchEvent(new MouseEvent(evtName, {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window
      }));
    });

    // (B) 觸發 React Form 表單的 requestSubmit
    if (form) {
      try {
        if (typeof form.requestSubmit === 'function') {
          form.requestSubmit(button);
        } else {
          form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
        }
      } catch (e) {}
    }

    return true;
  }

  // 4. 保底方案：點擊 Y 輸入框右側 25px 處的位置
  console.log('[PaGamO] 採用右側座標點擊保底...');
  const yRect = yInput.getBoundingClientRect();
  const targetX = yRect.right + 25;
  const targetY = yRect.top + yRect.height / 2;

  const clickTarget = document.elementFromPoint(targetX, targetY);
  if (clickTarget) {
    clickTarget.focus();
    clickTarget.click();
    return true;
  }

  return false;
}

/* ============================================================
 * 找座標輸入框
 * ============================================================ */

function findCoordinateInputs() {
  const inputs = Array.from(document.querySelectorAll('input'));

  const visible = inputs.filter(input => {
    const rect = input.getBoundingClientRect();
    return (
      rect.width > 0 &&
      rect.height > 0 &&
      rect.left >= 0 &&
      rect.top >= 0 &&
      rect.left < 500 &&
      rect.top < 500 &&
      !input.disabled &&
      !input.readOnly
    );
  });

  const numbers = visible.filter(input => input.type === 'number');

  if (numbers.length >= 2) {
    return numbers.slice(0, 2);
  }

  return visible.slice(0, 2);
}

/* ============================================================
 * 找座標跳轉按鈕
 * ============================================================ */

function findCoordinateButton(yInput) {
  const yRect = yInput.getBoundingClientRect();

  const elements = Array.from(
    document.querySelectorAll('button, [role="button"], a, div, i, span')
  );

  const candidates = elements.filter(element => {
    if (element.disabled) return false;

    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;

    // 必須極靠近 Y 座標欄位
    const nearY = Math.abs(rect.top - yRect.top) < 60;
    const nearX = rect.left >= yRect.left - 20 && rect.left <= yRect.right + 120;

    return nearX && nearY;
  });

  // 優先選取 class 或文字包含 search / submit 的元素
  for (const element of candidates) {
    const text = [
      element.innerText,
      element.textContent,
      element.getAttribute('aria-label'),
      element.getAttribute('title'),
      element.className
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    if (
      text.includes('search') ||
      text.includes('btn_search') ||
      text.includes('搜尋') ||
      text.includes('跳轉') ||
      text.includes('go')
    ) {
      return element;
    }
  }

  // 備用：包含 svg icon 的按鈕
  for (const element of candidates) {
    if (element.querySelector('svg') || element.tagName.toLowerCase() === 'svg') {
      return element;
    }
  }

  if (candidates.length > 0) {
    return candidates[0];
  }

  return null;
}

/* ============================================================
 * 設定 Input 原生 Value (觸發 React / Vue 狀態綁定)
 * ============================================================ */

function setNativeValue(element, value) {
  if (!element) return;

  const stringValue = String(value);
  element.focus();

  const prototype = Object.getPrototypeOf(element);
  const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');

  if (descriptor && descriptor.set) {
    descriptor.set.call(element, stringValue);
  } else {
    element.value = stringValue;
  }

  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

/* ============================================================
 * 停止與按鈕更新
 * ============================================================ */

function stopBot() {
  isBotRunning = false;
  updateButtons(false);
  setStatus('已停止');
}

function updateButtons(running) {
  const startButton = document.getElementById('bot-start-btn');
  const stopButton = document.getElementById('bot-stop-btn');

  if (startButton) {
    startButton.style.display = running ? 'none' : 'block';
  }

  if (stopButton) {
    stopButton.style.display = running ? 'block' : 'none';
  }
}

function setStatus(text) {
  const status = document.getElementById('bot-status-text');
  if (status) {
    status.textContent = text;
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}